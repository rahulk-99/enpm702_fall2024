class MyClass {
   public:
    static int count;  // Declaration of static attribute
    
};