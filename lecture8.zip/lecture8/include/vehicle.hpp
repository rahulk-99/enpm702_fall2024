#pragma once

#include <stdexcept>
#include <iostream>
#include <memory>
#include "driver.hpp"
#include "engine.hpp"

namespace driving {
class Driver;
class Engine;
class Vehicle {
   public:
    Vehicle(const std::string& model, const std::string& color, int horsepower) : model_{model}, color_{color}, engine_{std::make_unique<driving::Engine>(horsepower)} {}
    void set_driver(std::shared_ptr<driving::Driver> driver);
    void drive() const;

   private:
    std::string model_;
    std::string color_;
    std::unique_ptr<driving::Engine> engine_;
    std::shared_ptr<driving::Driver> driver_;

};  // class Vehicle
}  // namespace driving