#include "engine.hpp"

#include <iostream>

void driving::Engine::start() const {
    std::cout << "Engine (" << horsepower_ << " hp) has started\n";
}