
#include "vehicle.hpp"

#include <iostream>
#include <memory>

#include "driver.hpp"

void driving::Vehicle::drive() const {
    if (driver_) {
        if (engine_) {
            engine_->start();
            driver_->drive_vehicle();
            std::cout << "Vehicle (" << color_ << " " << model_ << ") is moving\n";
        }

    } else {
        std::cout << "No driver assigned to the vehicle\n";
        return;
    }
}

void driving::Vehicle::set_driver(std::shared_ptr<driving::Driver> driver) {
    driver_ = driver;
}