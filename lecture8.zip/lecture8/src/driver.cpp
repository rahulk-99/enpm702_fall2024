#include <iostream>

#include "driver.hpp"

void driving::Driver::drive_vehicle() const {
    std::cout << "Driver (" << name_ << ") is driving the vehicle\n";
}